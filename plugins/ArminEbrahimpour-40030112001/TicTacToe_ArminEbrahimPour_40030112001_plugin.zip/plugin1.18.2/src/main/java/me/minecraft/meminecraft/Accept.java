package me.minecraft.meminecraft;



import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


import static me.minecraft.meminecraft.Challenge.playerOne;
//import static me.minecraft.meminecraft.Challenge.playerTwo;

public class Accept implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(sender instanceof Player){
            Player player2 = ((Player) sender);
            if(player2.equals(Challenge.playerTwo)){
                player2.teleport(playerOne.getLocation().add(5,3,0));
                Play play = new Play(playerOne,player2);
                play.setPlayer1Turn(true);
                play.Board();
            }
            return true;
        }
        sender.sendMessage("You have not been challenged by any player!");
        return false;
    }
}
