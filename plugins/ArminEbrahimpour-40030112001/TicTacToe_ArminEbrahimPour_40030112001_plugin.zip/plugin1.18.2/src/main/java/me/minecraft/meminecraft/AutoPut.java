package me.minecraft.meminecraft;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class AutoPut implements Listener {
    @EventHandler
    public void AutoPutter(PlayerInteractEvent e){
        if(e.getHand() == EquipmentSlot.OFF_HAND){
            Material m = e.getPlayer().getTargetBlock(null,100).getType();
            if(m == Material.WHITE_WOOL){
                int pos = Play.play.getLocations().indexOf(e.getPlayer().getTargetBlockExact(1000).getLocation())+1;
                e.getPlayer().performCommand("put " + pos);
            }
        }
    }
}
