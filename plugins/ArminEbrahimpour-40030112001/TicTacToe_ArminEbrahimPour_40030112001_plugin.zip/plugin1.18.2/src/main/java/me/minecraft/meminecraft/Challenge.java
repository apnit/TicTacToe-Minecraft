package me.minecraft.meminecraft;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Challenge implements CommandExecutor {
    public static Player playerOne = null;
    public static Player playerTwo = null;
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if(sender instanceof Player){
            playerOne = (Player) sender;
            if(args.length == 0){
                playerOne.sendMessage("a Player name required for challenging ");
                return true;
            }
            if(playerOne.getDisplayName().equals(args[0])){
                playerOne.sendMessage("Hey you are challenging yourself in this server !!");
                return true;
            }

            for(Player player : Bukkit.getOnlinePlayers()){
                if(player.getDisplayName().equals(args[0])){
                    playerTwo = player;
                    playerTwo.sendMessage(playerOne.getDisplayName() + "is challenging you !!");
                    return true;
                }
            }
            playerOne.sendMessage("player Not Found !!!");
            return true;

        }
        return false;
    }
}