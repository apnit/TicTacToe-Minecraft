package me.minecraft.meminecraft;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class Deny implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(sender instanceof Player){
            Player player2  = (Player) sender;
                Challenge.playerOne = null;
                Challenge.playerTwo = null;
                player2.sendMessage("you Denied to play Have a good play in server :) ");
                return true;
            }
        return false;
        }
    }
