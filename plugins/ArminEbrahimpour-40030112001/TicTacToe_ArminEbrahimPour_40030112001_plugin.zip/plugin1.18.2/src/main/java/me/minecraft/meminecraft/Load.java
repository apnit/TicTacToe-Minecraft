package me.minecraft.meminecraft;

import org.bukkit.Bukkit;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import static me.minecraft.meminecraft.Challenge.playerOne;
import static me.minecraft.meminecraft.Challenge.playerTwo;
import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;



public class Load implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if(sender instanceof Player){
            String fileName = args[0];

            int reds = 0;
            int blues = 0;
            char[] chr;
            try {
                BufferedReader br = new  BufferedReader(new FileReader(fileName));
                String firstName = br.readLine();
                String secondName = br.readLine();
                if(((Player) sender).getDisplayName().equals(firstName)){
                    playerOne = (Player) sender;
                    for(Player player : Bukkit.getOnlinePlayers()){
                        if(((Player) sender).getDisplayName().equals(secondName)){
                            playerTwo = player;
                        }
                    }
                }else {
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        if (((Player) sender).getDisplayName().equals(secondName)) {
                            playerOne = player;
                        }
                    }
                    playerTwo = (Player) sender;
                }
//                sender.sendMessage("passed the player initialization");
                Play playL = new Play(playerOne,playerTwo);
//                sender.sendMessage("passed the play maker");
                playL.Board();
                try {
                    String Line = br.readLine();
                    while (Line!= null){
                        chr = Line.toCharArray();
//                        sender.sendMessage("passed char array initialization this is char array :"+ Arrays.toString(chr));

                        if(chr[0] =='r'){
//                            sender.sendMessage("passed if ");
                            reds+=1;
//                            sender.sendMessage("this is chr[1]:"+chr[1]);
                            int pos = Integer.parseInt(String.valueOf(chr[1]));

//                            sender.sendMessage("Board created");

                            playL.getLocations().get((pos-1)).getBlock().setType(Material.RED_WOOL);

//                            sender.sendMessage("passed reds+=1 and put");
                        }else if (chr[0] == 'b'){
                            blues+=1;
                            int pos = Integer.parseInt(String.valueOf(chr[1]));
                            playL.getLocations().get((pos-1)).getBlock().setType(Material.BLUE_WOOL);

//                            sender.sendMessage("passed blues+=1 and put ");
                        }
                        Line = br.readLine();
                    }
//                    sender.sendMessage("passed the whole reading process");

                }catch (Exception N){
                    System.out.println(N.getMessage());
                }

                if(reds == blues){
                    Play.play.setPlayer1Turn(true);
                    Play.play.setPlayer2Turn(false);
                }else{
                    Play.play.setPlayer1Turn(false);
                    Play.play.setPlayer2Turn(true);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        }
        return false;
    }
}
