package me.minecraft.meminecraft;

import org.bukkit.plugin.java.JavaPlugin;

public final class MeMinecraft extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        System.out.println("Start this Project");
        getServer().getPluginCommand("challenge").setExecutor(new Challenge());
        getServer().getPluginCommand("accept").setExecutor(new Accept());
        getServer().getPluginCommand("deny").setExecutor(new Deny());
        getServer().getPluginCommand("put").setExecutor(new Put());
        getServer().getPluginCommand("save").setExecutor(new Save());
        getServer().getPluginCommand("load").setExecutor(new Load());
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
