package me.minecraft.meminecraft;


import org.bukkit.*;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;

import java.util.ArrayList;


import static me.minecraft.meminecraft.Challenge.playerOne;

public class Play {
    public static Play play = null;
    private Player player1;
    private Player player2;
    private ArrayList<Integer> p1Location = new ArrayList<>();
    private ArrayList<Integer> p2Location = new ArrayList<>();
    private ArrayList<Location> locations = new ArrayList<>();
    private boolean isPlayer1Turn = false;
    private boolean isPlayer2Turn = false;

    public static void setPlay(Play play) {
        Play.play = play;
    }

    public void setPlayer1(Player player1) {
        this.player1 = player1;
    }

    public void setPlayer2(Player player2) {
        this.player2 = player2;
    }

    public void setP1Location(ArrayList<Integer> p1Location) {
        this.p1Location = p1Location;
    }

    public void setP2Location(ArrayList<Integer> p2Location) {
        this.p2Location = p2Location;
    }

    public void setLocations(ArrayList<Location> locations) {
        this.locations = locations;
    }

    public void setPlayer1Turn(boolean player1Turn) {
        isPlayer1Turn = player1Turn;
    }

    public void setPlayer2Turn(boolean player2Turn) {
        isPlayer2Turn = player2Turn;
    }

    public static Play getPlay() {
        return play;
    }

    public Player getPlayer1() {
        return player1;
    }

    public Player getPlayer2() {
        return player2;
    }

    public ArrayList<Integer> getP1Location() {
        return p1Location;
    }

    public ArrayList<Integer> getP2Location() {
        return p2Location;
    }

    public ArrayList<Location> getLocations() {
        return locations;
    }

    public boolean isPlayer1Turn() {
        return isPlayer1Turn;
    }

    public boolean isPlayer2Turn() {
        return isPlayer2Turn;
    }

    public Play (Player player1, Player player2){
        this.player1 = player1;
        this.player2 = player2;
        play = this;
    }
    public void Board(){
        World world = playerOne.getWorld();
        int x = playerOne.getLocation().getBlockX();
        int y = playerOne.getLocation().getBlockY();
        int z = playerOne.getLocation().getBlockZ();

        for(int i = 2 ; i > -1;i--){
            for(int j = -1 ; j < 2 ; j++){
                locations.add(new Location(world,x+j,y+i,z-5));
            }
        }
        for(Location location : locations){
            location.getBlock().setType(Material.WHITE_WOOL);
        }


    }
    public void put(int pos, Player player){

            if(player.equals(playerOne)){
                locations.get((pos -1)).getBlock().setType(Material.RED_WOOL);
                p1Location.add(pos);
                setPlayer1Turn(false);
                setPlayer2Turn(true);
            }else{
                locations.get((pos -1)).getBlock().setType(Material.BLUE_WOOL);
                p2Location.add(pos);
                setPlayer2Turn(false);
                setPlayer1Turn(true);
            }



    }


    public boolean winnerCheck() {
//        //generating firework:
//        Firework fw = (Firework) playerOne.getWorld().spawnEntity(playerOne.getLocation(), EntityType.FIREWORK);
//        FireworkMeta fwmR = fw.getFireworkMeta();
//        FireworkMeta fwmB = fw.getFireworkMeta();
//        //set color:
//        FireworkEffect efB = FireworkEffect.builder().withColor(Color.BLUE).build();
//        FireworkEffect efR = FireworkEffect.builder().withColor(Color.RED).build();
//        fwmB.addEffect(efB);
//        fwmR.addEffect(efR);
//        //set power:
//        fwmR.setPower(2);
//        fwmB.setPower(2);

        // horizontal p1 winner
        if (p1Location.contains(1) && p1Location.contains(2) && p1Location.contains(3)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");

            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        if (p1Location.contains(4) && p1Location.contains(5) && p1Location.contains(6)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;

            return true;
        }
        if (p1Location.contains(7) && p1Location.contains(8) && p1Location.contains(9)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        //vertical p1 winner
        if (p1Location.contains(1) && p1Location.contains(4) && p1Location.contains(7)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        if (p1Location.contains(2) && p1Location.contains(5) && p1Location.contains(8)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        if (p1Location.contains(3) && p1Location.contains(6) && p1Location.contains(9)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        // X p1 winner
        if (p1Location.contains(1) && p1Location.contains(5) && p1Location.contains(9)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        if (p1Location.contains(3) && p1Location.contains(5) && p1Location.contains(7)) {
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            player2.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmR);
            play = null;
            return true;
        }
        //========================================p2 winner=================================================
        // horizontal p1 winner
        if (p2Location.contains(1) && p2Location.contains(2) && p2Location.contains(3)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        if (p2Location.contains(4) && p2Location.contains(5) && p2Location.contains(6)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        if (p2Location.contains(7) && p2Location.contains(8) && p2Location.contains(9)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        //vertical p1 winner
        if (p2Location.contains(1) && p2Location.contains(4) && p2Location.contains(7)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        if (p2Location.contains(2) && p2Location.contains(5) && p2Location.contains(8)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        if (p2Location.contains(3) && p2Location.contains(6) && p2Location.contains(9)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        // X p1 winner
        if (p2Location.contains(1) && p2Location.contains(5) && p2Location.contains(9)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }
        if (p2Location.contains(3) && p2Location.contains(5) && p2Location.contains(7)) {
            player2.sendMessage(player2.getDisplayName() + " Won this game and " + player1.getDisplayName() + " Lose this game");
            player1.sendMessage(player1.getDisplayName() + " Won this game and " + player2.getDisplayName() + " Lose this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
//            fw.setFireworkMeta(fwmB);
            play = null;
            return true;
        }

        // checks for tie:
        boolean tie = true;
        for (Location location : locations) {
            if(location.getBlock().getType().equals(Material.WHITE_WOOL)){
                tie = false;
            }
        }
        if(tie){
            player1.sendMessage("You Tie this game");
            player2.sendMessage("You Tie this game");
            for (Location location : locations) {
                location.getBlock().setType(Material.AIR);
            }
            play = null;
            return true;
        }

            return false;
        }
}

