package me.minecraft.meminecraft;


import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Put implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if(sender instanceof Player){
            Player player = (Player) sender;
            int pos;
            try {
                pos = Integer.parseInt(args[0]);
            }catch (NumberFormatException N){
                player.sendMessage(N.getMessage());
                return false;
            }
            if(player.equals(Play.play.getPlayer1())) {
                if (Play.play.isPlayer1Turn()) {
                    if (Play.play.getP1Location().contains(pos) || Play.play.getP2Location().contains(pos)) {
                        player.sendMessage("This place is already taken! you can not place it here!!");
                        return true;
                    }
                Play.play.put(pos,player);
                if(Play.play.winnerCheck()){
                    Play.play = null;
                    return true;
                }
                } else {
                    player.sendMessage("It's not yur turn");
                    return true;
                }
            }else if(player.equals(Play.play.getPlayer2())){
                if (Play.play.isPlayer2Turn()) {
                    if (Play.play.getP1Location().contains(pos) || Play.play.getP2Location().contains(pos)) {
                        player.sendMessage("This place is already taken! you can not place it here!!");
                        return true;
                    }
                    Play.play.put(pos, player);
                    if(Play.play.winnerCheck()){
                        Play.play = null;
                        return true;
                    }

                } else {
                    player.sendMessage("It's not yur turn");
                    return true;
                }
            }

        }
        return false;
    }
}
