package me.minecraft.meminecraft;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import static me.minecraft.meminecraft.Challenge.playerOne;
import static me.minecraft.meminecraft.Challenge.playerTwo;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Save implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if(sender instanceof Player){
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss");
            LocalDateTime now =  LocalDateTime.now();
            String fileName = playerOne.getDisplayName() + "_" +playerTwo.getDisplayName() + dtf.format(now);


            try {
                FileWriter fw = new FileWriter(fileName);
                //sender.sendMessage("file built ");
                fw.write(playerOne.getDisplayName()+System.lineSeparator());
                fw.write(playerTwo.getDisplayName()+System.lineSeparator());
                for(Integer locations : Play.play.getP1Location()){
                    fw.write('r');
                    fw.write(locations+System.lineSeparator());
                }
                //sender.sendMessage("location p1 passed");
                for(Integer locations : Play.play.getP2Location()){
                    fw.write('b');
                    fw.write(locations+System.lineSeparator());
                }
                sender.sendMessage("You saved this file successfully");
                fw.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        }

        return false;
    }
}
